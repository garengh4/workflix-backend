package com.infy.workflix.api;

import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin
public class login {
}
