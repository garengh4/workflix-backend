package com.infy.workflix.service;

public class Service {
}
